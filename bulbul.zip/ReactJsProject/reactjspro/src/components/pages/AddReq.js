import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class AddReq extends Component{

 

    render(){

 

        return <div>
            <h1>Add Request</h1>
            <table>
                <tr>
                    <td>Employee Name</td>
                    <td>Shuvo Khan</td>
                </tr>
                <tr>
                    <td>Employee Id</td>
                    <td>555555</td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>shuvo@mail.com</td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>Male</td>
                </tr>
                <tr>
                    <td>DOB</td>
                    <td>17-01-1995</td>
                </tr>
                <tr>
                    <td>Phone Number</td>
                    <td>01799457859</td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td>Available</td>
                </tr>
                <tr>
                    <td>Type</td>
                    <td>Accountant</td>
                </tr>
                <tr>
                    <td>Salary</td>
                    <td>17000</td>
                </tr>
                <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Add"></input></td>
             <td><input type="submit" value = "Reject"></input></td>
           </tr>
            </table>
        </div>
    }

 


} 

 

export default AddReq