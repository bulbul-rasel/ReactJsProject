import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class ViewEmp extends Component{

 

    render(){

 

        return <div>
            <h1>View Employee</h1>
            <table>
  <tr>
    <td>Employee Name</td>
    <td>Employee Id</td>
    <td>Email</td>
    <td>Gender</td>
    <td>DOB</td>
    <td>Phone Number</td>
    <td>Status</td>
    <td>Type</td>
    <td>Salary</td>
  </tr>
  <tr>
    <td>Raju Ahmed</td>
    <td>111111</td>
    <td>raju@email.com</td>
    <td>Male</td>
    <td>22-08-1992</td>
    <td>01589458724</td>
    <td>Available</td>
    <td>Seller</td>
    <td>15000</td>
  </tr>
  <tr>
    <td>Rita Haque</td>
    <td>222222</td>
    <td>rita@email.com</td>
    <td>Female</td>
    <td>12-03-1995</td>
    <td>01985458742</td>
    <td>Available</td>
    <td>Accountant</td>
    <td>20000</td>
  </tr>
  <tr>
    <td>Sabbir Ahmed</td>
    <td>333333</td>
    <td>sabbir@email.com</td>
    <td>Male</td>
    <td>08-09-1993</td>
    <td>01809457821</td>
    <td>Available</td>
    <td>Admin</td>
    <td>22000</td>
  </tr>
</table>
        </div>
    }

 


} 

 

export default ViewEmp