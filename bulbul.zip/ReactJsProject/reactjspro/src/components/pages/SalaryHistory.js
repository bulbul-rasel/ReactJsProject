import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class SalaryHistory extends Component{

 

    render(){

 

        return <div>
            <h1>Salary History</h1>
            <tr>
    <td>Employee Name</td>
    <td>Employee Id</td>
    <td>Status</td>
    <td>Salary</td>
    <td>Date</td>
  </tr>
  <tr>
    <td>Raju Ahmed</td>
    <td>111111</td>
    <td>Pending</td>
    <td>15000</td>
    <td>12-04-2020</td>
  </tr>
  <tr>
    <td>Rita Haque</td>
    <td>222222</td>
    <td>Pending</td>
    <td>20000</td>
    <td>08-04-2020</td>
  </tr>
  <tr>
    <td>Sabbir Ahmed</td>
    <td>333333</td>
    <td>Clear</td>
    <td>22000</td>
    <td>05-04-2020</td>
  </tr>

        </div>
    }

 


} 

 

export default SalaryHistory