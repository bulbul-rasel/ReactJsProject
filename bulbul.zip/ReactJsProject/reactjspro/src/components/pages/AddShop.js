import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class AddShop extends Component{

 

    render(){

 

        return <div>
            <h2>Add Shop</h2>

            <table>
           <tr>
             <td>Shop Name</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Shop ID</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Status</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Location</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Type</td>
             <td><input type="text"></input></td>
           </tr>
           
           <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Submit"></input></td>
           </tr>
        </table>
        </div>
    }

 


} 

 

export default AddShop 