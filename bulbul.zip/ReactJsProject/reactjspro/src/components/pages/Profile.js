import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class Profile extends Component{

 

    render(){

 

        return <div>
            <h1>Profile</h1>
            <table>
                <tr>
                    <td>Employee Name</td>
                    <td>Sabbir Ahmed</td>
                </tr>
                <tr>
                    <td>Employee Id</td>
                    <td>333333</td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>sabbir@mail.com</td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>Male</td>
                </tr>
                <tr>
                    <td>DOB</td>
                    <td>08-09-1993</td>
                </tr>
                <tr>
                    <td>Phone Number</td>
                    <td>01809457821</td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td>Available</td>
                </tr>
                <tr>
                    <td>Type</td>
                    <td>Admin</td>
                </tr>
                <tr>
                    <td>Salary</td>
                    <td>22000</td>
                </tr>
            </table>
        </div>
    }

 


} 

 

export default Profile