import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class SalaryReq extends Component{

 

    render(){

 

        return <div>
            <h1>Salary Request</h1>
            <table>
                <tr>
                    <td>Employee Name</td>
                    <td>Raju Ahmed</td>
                </tr>
                <tr>
                    <td>Employee Id</td>
                    <td>111111</td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>raju@mail.com</td>
                </tr>
                
                <tr>
                    <td>Request</td>
                    <td>Increse</td>
                </tr>
                <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Add"></input></td>
             <td><input type="submit" value = "Reject"></input></td>
           </tr>

           <tr>
                    <td>Employee Name</td>
                    <td>Sabbir Ahmed</td>
                </tr>
                <tr>
                    <td>Employee Id</td>
                    <td>333333</td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>sabbir@mail.com</td>
                </tr>
                
                <tr>
                    <td>Request</td>
                    <td>Advance Payment</td>
                </tr>
                <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Add"></input></td>
             <td><input type="submit" value = "Reject"></input></td>
           </tr>
            </table>
        </div>
    }

 


} 

 

export default SalaryReq