import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class AddEmp extends Component{

 

    render(){

 

        return <div>
            <h2>Add Employee</h2>
        
            <table>
           <tr>
             <td>Employee Name</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Employee ID</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Email</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Gender</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>DOB</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Phone Number</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Status</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Type</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Salary</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Submit"></input></td>
           </tr>
        </table>
        </div>
    
    }

 


} 

 

export default AddEmp 