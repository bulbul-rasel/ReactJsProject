import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class SearchEmp extends Component{

 

    render(){

 

        return <div>
            <h1>Search Employee</h1>
            <tr>
             <td>Employee ID</td>
             <td><input type="text"></input></td>
           </tr>
           
           <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Search"></input></td>
           </tr>
        </div>
    }

 


} 

 

export default SearchEmp