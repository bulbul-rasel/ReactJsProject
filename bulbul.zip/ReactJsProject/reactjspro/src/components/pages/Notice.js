import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class Notice extends Component{

 

    render(){

 

        return <div>
            <h1>Notice</h1>
            <tr>
             <td>Notice</td>
             <td><input type="text"></input></td>
           </tr>
           
           <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Submit"></input></td>
           </tr>
        </div>
    }

 


} 

 

export default Notice