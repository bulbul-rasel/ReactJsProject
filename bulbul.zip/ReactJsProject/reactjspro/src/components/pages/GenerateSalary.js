import React, {Component} from 'react';
import ReactDOM from 'react-dom';

 

class GenerateSalary extends Component{

 

    render(){

 

        return <div>
            <h1>Generate Salary</h1>
            <tr>
             <td>Employee Name</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Employee Id</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Status</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Salary</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td>Date</td>
             <td><input type="text"></input></td>
           </tr>
           <tr>
             <td><br></br></td>
             <td><input type="submit" value = "Submit"></input></td>
           </tr>
        </div>
    }

 


} 

 

export default GenerateSalary 