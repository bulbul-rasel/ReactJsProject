import React, {Component} from 'react';
import {Link} from 'react-router-dom';
 
class Navbar extends Component{
 
    render(){
 
        return <div>
            <ul>
                <li><Link to = "/">Home</Link></li>
                <li><Link to = "/profile">Profile</Link></li>
                <li><Link to = "/addemp">Add Employees</Link></li>
                <li><Link to = "/addshop">Add Shop</Link></li>
                <li><Link to = "/addreq">Add Request</Link></li>
                <li><Link to = "/viewemp">View Employees</Link></li>
                <li><Link to = "/notice">Notice</Link></li>
                <li><Link to = "/searchemp">Search Employees</Link></li>
                <li><Link to = "/salaryhistory">Salary History</Link></li>
                <li><Link to = "/generatesalary">Generate Salary</Link></li>
                <li><Link to = "/salaryreq">Salary Request</Link></li>
                
            </ul>
        </div>
    }
 
} 
 
export default Navbar