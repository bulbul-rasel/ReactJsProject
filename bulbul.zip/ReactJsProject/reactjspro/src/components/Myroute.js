import React, {Component} from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

import Home from './pages/Home'

import AddReq from './pages/AddReq'
import Profile from './pages/Profile'
import AddEmp from './pages/AddEmp'
import Notice from './pages/Notice'
import SalaryHistory from './pages/SalaryHistory'
import SearchEmp from './pages/SearchEmp'
import ViewEmp from './pages/ViewEmp'
import AddShop from './pages/AddShop'
import GenerateSalary from './pages/GenerateSalary'
import SalaryReq from './pages/SalaryReq'


 
class Myroute extends Component{
 
    render(){
 
        return( 
        <div>
            <Route exact path="/" component ={Home} />
            
            
            <Route path="/profile" component ={Profile} />

            <Route path="/addreq" component ={AddReq} />
            <Route path="/addshop" component ={AddShop} />
            <Route path="/addemp" component ={AddEmp} />
            <Route path="/notice" component ={Notice} />
            <Route path="/salaryhistory" component ={SalaryHistory} />
            <Route path="/salaryreq" component ={SalaryReq} />
            <Route path="/generatesalary" component ={GenerateSalary} />
            <Route path="/searchemp" component ={SearchEmp} />
            <Route path="/viewemp" component ={ViewEmp} />
            
            
        </div>
        );
    }
 
} 
 
export default Myroute