import React from 'react';
import ReactDOM from 'react-dom';
//import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar'
import Myroute from './components/Myroute'
import { BrowserRouter } from 'react-router-dom';


 
function App() {
  return (
    <div >
      
      <BrowserRouter>
        <Navbar/>
        <Myroute/>
      </BrowserRouter>
 
    </div>
  );
}
 
export default App;